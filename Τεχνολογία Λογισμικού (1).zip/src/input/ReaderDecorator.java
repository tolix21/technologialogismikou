package input;

import java.util.List;

public abstract class ReaderDecorator implements DocumentReader{
	protected DocumentReader componentReader;
	
	public ReaderDecorator(DocumentReader componentReader) {
		this.componentReader = componentReader;
	}
	
	public abstract List<String> read();
}
