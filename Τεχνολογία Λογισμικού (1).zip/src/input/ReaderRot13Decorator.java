package input;

import java.util.ArrayList;
import java.util.List;

public class ReaderRot13Decorator extends ReaderDecorator{

	public ReaderRot13Decorator(DocumentReader componentReader) {
		super(componentReader);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<String> read() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		List<String> contents = componentReader.read();
		List<String> decodedContents = new ArrayList<String>();
		
		for(int i = 0; i < contents.size(); i++) {
			String contentsI = contents.get(i);
			String newContentsI = "";
			for(int j = 0; j < contentsI.length(); j++) {
				char c = contentsI.charAt(j);
				if(c >= 'a' && c <= 'z') {
					int newPosition = (13 + (c - 'a'))%26;
					c = (char)('a' + newPosition);
				}
				else if(c >= 'A' && c <= 'Z') {
					int newPosition = (13 + (c - 'A'))%26;
					c = (char)('A' + newPosition);
				}
				newContentsI = newContentsI + c;
			}
			decodedContents.add(newContentsI);
		}
		return decodedContents;
	}

}
