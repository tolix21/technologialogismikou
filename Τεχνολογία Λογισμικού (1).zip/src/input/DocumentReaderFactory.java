package input;

public class DocumentReaderFactory {
	
	private WordReader wordReader;
	private ExcelReader excelReader;
	private ReaderAtbashDecorator readerAtbashDecorator;
	private ReaderRot13Decorator readerRot13Decorator;
	
	public DocumentReaderFactory() {
		wordReader = new WordReader();
		excelReader = new ExcelReader();
	}
	
	public DocumentReader createReader(String fileName, String type, String encoding) {
		DocumentReader component = null;

		if(type.equals("Word")) {
			wordReader.setFileName(fileName);
			component = wordReader;
		}
		else if(type.equals("Excel")) {
			excelReader.setFileName(fileName);
			component = excelReader;
		}
		else {
			return null;
		}
		
		if(encoding.equals("None")) {
			return component;
		}
		else if(encoding.equals("Atbash")){
			readerAtbashDecorator = new ReaderAtbashDecorator(component);
			return readerAtbashDecorator;
		}
		else if(encoding.equals("Rot13")) {
			readerRot13Decorator = new ReaderRot13Decorator(component);
			return readerRot13Decorator;
		}
		return null;
	}
}
