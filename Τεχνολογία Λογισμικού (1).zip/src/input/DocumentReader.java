package input;

import java.util.List;

public interface DocumentReader {
	public List<String> read();
}
