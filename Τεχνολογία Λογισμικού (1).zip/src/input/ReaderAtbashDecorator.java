package input;

import java.util.ArrayList;
import java.util.List;

public class ReaderAtbashDecorator extends ReaderDecorator{

	public ReaderAtbashDecorator(DocumentReader componentReader) {
		super(componentReader);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<String> read() {
		// TODO Auto-generated method stub
		List<String> contents = componentReader.read();
		List<String> decodedContents = new ArrayList<String>();
		
		for(int i = 0; i < contents.size(); i++) {
			String contentsI = contents.get(i);
			String newContentsI = "";
			for(int j = 0; j < contentsI.length(); j++) {
				char c = contentsI.charAt(j);
				if(c >= 'a' && c <= 'z') {
					int newPosition = 25 - (c - 'a');
					c = (char)('a' + newPosition);
				}
				else if(c >= 'A' && c <= 'Z') {
					int newPosition = 25 - (c - 'A');
					c = (char)('A' + newPosition);
				}
				newContentsI = newContentsI + c;
			}
			decodedContents.add(newContentsI);
		}
		return decodedContents;
	}

}
