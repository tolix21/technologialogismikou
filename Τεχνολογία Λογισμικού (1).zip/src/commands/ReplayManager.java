package commands;

import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ReplayManager {
	private boolean recordingStatus;
	private ArrayList<ActionListener> commandList;
	
	public ReplayManager() {
		commandList = new ArrayList<ActionListener>();
	}
	
	public void addCommand(ActionListener command) {
		commandList.add(command);
	}
	public void replay() {
		ArrayList<ActionListener> temp = new ArrayList<ActionListener>();
		temp.addAll(commandList);
		int size = commandList.size();
		for(int i = 0; i < size; i++) {
			ActionListener command = commandList.get(i);
			command.actionPerformed(null);
		}
		commandList = temp;
		System.out.println("Hello " + commandList.size());
	}
	
	public void startRecording() {
		recordingStatus = true;
	}
	
	public void endRecording() {
		recordingStatus = false;
		commandList.clear();
	}
	
	public boolean isActiveRecording() {
		return recordingStatus;
	}
}
