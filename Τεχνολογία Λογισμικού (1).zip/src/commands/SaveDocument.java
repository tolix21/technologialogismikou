package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Document;

public class SaveDocument implements ActionListener{
	private Document document;
	private ReplayManager replayManager;
	private String fileName;
	private String type;
	private String encoding;
	
	public SaveDocument() {
		
	}
	
	public void setDocument(Document document) {
		this.document = document;
	}
	
	public void setReplayManager(ReplayManager replayManager) {
		this.replayManager = replayManager;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Save");
		
		document.save(fileName, type, encoding);
		
	}
	
	public void giveInfo(String fileName, String type, String encoding) {
		this.fileName = fileName;
		this.type = type;
		this.encoding = encoding;
	}
}
