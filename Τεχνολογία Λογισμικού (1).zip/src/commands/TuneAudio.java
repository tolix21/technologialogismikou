package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;

import model.Document;
import model.TTSFacade;

public class TuneAudio implements ActionListener {
	
	private TTSFacade audioManager;
	private ReplayManager replayManager;
	private float volume;
	private float pitch;
	private float rate;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Tune");
		
		if(volume != -1)
			audioManager.setVolume(volume);
		if(pitch != -1)
			audioManager.setPitch(pitch);
		if(rate != -1)
			audioManager.setRate(rate);
		
	}
	
	public void setAudioManager(TTSFacade audioManager) {
		this.audioManager = audioManager;
	}
	
	public void setReplayManager(ReplayManager replayManager) {
		this.replayManager = replayManager;
	}
	
	public void giveInfo(float volume, float pitch, float rate) {
		this.volume = volume;
		this.pitch = pitch;
		this.rate = rate;
	}

}
