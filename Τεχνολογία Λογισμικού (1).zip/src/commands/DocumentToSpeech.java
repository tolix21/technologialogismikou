package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import javax.swing.Action;

import model.Document;

public class DocumentToSpeech implements ActionListener {
	
	private Document document;
	private ReplayManager replayManager;
	private int start;
	private int end;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Transform");
		if(replayManager.isActiveRecording())
			replayManager.addCommand(copy());
		
		if(start == -1) {
			document.playContents();
		}
		else {
			for(int i = start; i <= end; i++) {
				document.playLine(i);
			}
		}
	}
	
	private ActionListener copy() {
		// TODO Auto-generated method stub
		DocumentToSpeech actionListener = new DocumentToSpeech();
		actionListener.document = new Document(document);
		actionListener.start = start;
		actionListener.end = end;
		actionListener.replayManager = new ReplayManager();
		return actionListener;
	}

	public void setDocument(Document document) {
		this.document = document;
	}
	
	public void setReplayManager(ReplayManager replayManager) {
		this.replayManager = replayManager;
	}
	
	public void giveInfo(int start, int end) {
		this.start = start;
		this.end = end;
	}

}
