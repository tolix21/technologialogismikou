package commands;

import java.awt.event.ActionListener;

public class CommandsFactory {
	
	public CommandsFactory() {
		
	}
	
	public ActionListener createCommand(String command) {
		if(command.equals("OpenDocument"))
			return new OpenDocument();
		if(command.equals("EditDocument"))
			return new EditDocument();
		if(command.equals("SaveDocument"))
			return new SaveDocument();
		if(command.equals("StartRecording"))
			return new StartRecording();
		if(command.equals("EndRecording"))
			return new EndRecording();
		if(command.equals("Replay"))
			return new ReplayCommand();
		if(command.equals("Transform"))
			return new DocumentToSpeech();
		if(command.equals("Tune"))
			return new TuneAudio();
		return null;
	}
}
