package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartRecording implements ActionListener{
	private ReplayManager replayManager;
	
	public StartRecording() {
		
	}
	
	public void setReplayManager(ReplayManager replayManager) {
		this.replayManager = replayManager;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		replayManager.startRecording();
	}
	
}
