package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import commands.CommandsFactory;
import commands.ReplayManager;
import commands.StartRecording;

public class StartRecordingTest {

	@Test
	public void testActionPerformed() {
		CommandsFactory commandsFactory = new CommandsFactory();
		StartRecording startRecording = (StartRecording) commandsFactory.createCommand("StartRecording");
		
		ReplayManager replayManager = new ReplayManager();
		startRecording.setReplayManager(replayManager);
		
		startRecording.actionPerformed(null);
		
		assertEquals(true, replayManager.isActiveRecording());
	}

}
