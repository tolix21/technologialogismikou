package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import commands.CommandsFactory;
import commands.EditDocument;
import commands.ReplayManager;
import model.Document;

public class EditDocumentTest {

	@Test
	public void testActionPerformed() {
		CommandsFactory commandsFactory = new CommandsFactory();
		EditDocument editDocument = (EditDocument) commandsFactory.createCommand("EditDocument");
		ReplayManager replayManager = new ReplayManager();
		editDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		editDocument.setDocument(document);
		
		String text = "This is a test\nfor checking edit document";
		editDocument.giveInfo(text);
		editDocument.actionPerformed(null);
		
		assertEquals(text, document.toString());
		
	}

}
