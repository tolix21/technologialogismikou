package tests;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.junit.Test;

import commands.CommandsFactory;
import commands.OpenDocument;
import commands.ReplayManager;
import commands.StartRecording;
import input.DocumentReaderFactory;
import model.Document;

public class OpenDocumentTest {

	@Test
	public void testActionPerformed() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.docx", "Word", "None");
		openDocument.actionPerformed(null);
		
		String text = "";
		
		try (XWPFDocument doc = new XWPFDocument(
                Files.newInputStream(Paths.get("test.docx")))) {

            
            List<XWPFParagraph> list = doc.getParagraphs();
            for (XWPFParagraph paragraph : list) {
                text = text + paragraph.getText() + "\n";
            }

        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		text = text.strip();
		assertEquals(text, document.toString());
	}
	
	@Test
	public void testActionPerformedExcel() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.xlsx", "Excel", "None");
		openDocument.actionPerformed(null);
		
		String text = "";
		
		try {

            FileInputStream excelFile = new FileInputStream(new File("test.xlsx"));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator();

            while (iterator.hasNext()) {

                Row currentRow = iterator.next();
                Iterator<Cell> cellIterator = currentRow.iterator();

                while (cellIterator.hasNext()) {
                	
                    Cell currentCell = cellIterator.next();
                    //getCellTypeEnum shown as deprecated for version 3.15
                    //getCellTypeEnum ill be renamed to getCellType starting from version 4.0
                    text = text + currentCell.toString() + "\t";
                }
                text = text + "\n";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		text = text.strip();
		assertEquals(text, document.toString());
	}
	
	@Test
	public void testActionPerformedAtbash() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.docx", "Word", "Atbash");
		openDocument.actionPerformed(null);
		
		String text = "";
		
		try (XWPFDocument doc = new XWPFDocument(
                Files.newInputStream(Paths.get("test.docx")))) {

            
            List<XWPFParagraph> list = doc.getParagraphs();
            for (XWPFParagraph paragraph : list) {
                text = text + paragraph.getText() + "\n";
            }

        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String oldText = text.strip();
		text = "";
		for(int j = 0; j < oldText.length(); j++) {
			char c = oldText.charAt(j);
			if(c >= 'a' && c <= 'z') {
				int newPosition = 25 - (c - 'a');
				c = (char)('a' + newPosition);
			}
			else if(c >= 'A' && c <= 'Z') {
				int newPosition = 25 - (c - 'A');
				c = (char)('A' + newPosition);
			}
			text = text + c;
		}
		assertEquals(text, document.toString());
	}
	
	@Test
	public void testActionPerformedExcelAtbash() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.xlsx", "Excel", "Atbash");
		openDocument.actionPerformed(null);
		
		String text = "";
		
		try {

            FileInputStream excelFile = new FileInputStream(new File("test.xlsx"));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator();

            while (iterator.hasNext()) {

                Row currentRow = iterator.next();
                Iterator<Cell> cellIterator = currentRow.iterator();

                while (cellIterator.hasNext()) {
                	
                    Cell currentCell = cellIterator.next();
                    //getCellTypeEnum shown as deprecated for version 3.15
                    //getCellTypeEnum ill be renamed to getCellType starting from version 4.0
                    text = text + currentCell.toString() + "\t";
                }
                text = text + "\n";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		text = text.strip();
		String oldText = text.strip();
		text = "";
		for(int j = 0; j < oldText.length(); j++) {
			char c = oldText.charAt(j);
			if(c >= 'a' && c <= 'z') {
				int newPosition = 25 - (c - 'a');
				c = (char)('a' + newPosition);
			}
			else if(c >= 'A' && c <= 'Z') {
				int newPosition = 25 - (c - 'A');
				c = (char)('A' + newPosition);
			}
			text = text + c;
		}
		assertEquals(text, document.toString());
	}
	
	@Test
	public void testActionPerformedRot13() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.docx", "Word", "Rot13");
		openDocument.actionPerformed(null);
		
		String text = "";
		
		try (XWPFDocument doc = new XWPFDocument(
                Files.newInputStream(Paths.get("test.docx")))) {

            
            List<XWPFParagraph> list = doc.getParagraphs();
            for (XWPFParagraph paragraph : list) {
                text = text + paragraph.getText() + "\n";
            }

        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String oldText = text.strip();
		text = "";
		for(int j = 0; j < oldText.length(); j++) {
			char c = oldText.charAt(j);
			if(c >= 'a' && c <= 'z') {
				int newPosition = (13 + (c - 'a'))%26;
				c = (char)('a' + newPosition);
			}
			else if(c >= 'A' && c <= 'Z') {
				int newPosition = (13 + (c - 'A'))%26;
				c = (char)('A' + newPosition);
			}
			text = text + c;
		}
		assertEquals(text, document.toString());
	}
	
	@Test
	public void testActionPerformedExcelRot13() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.xlsx", "Excel", "Rot13");
		openDocument.actionPerformed(null);
		
		String text = "";
		
		try {

            FileInputStream excelFile = new FileInputStream(new File("test.xlsx"));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator();

            while (iterator.hasNext()) {

                Row currentRow = iterator.next();
                Iterator<Cell> cellIterator = currentRow.iterator();

                while (cellIterator.hasNext()) {
                	
                    Cell currentCell = cellIterator.next();
                    //getCellTypeEnum shown as deprecated for version 3.15
                    //getCellTypeEnum ill be renamed to getCellType starting from version 4.0
                    text = text + currentCell.toString() + "\t";
                }
                text = text + "\n";
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		String oldText = text.strip();
		text = "";
		for(int j = 0; j < oldText.length(); j++) {
			char c = oldText.charAt(j);
			if(c >= 'a' && c <= 'z') {
				int newPosition = (13 + (c - 'a'))%26;
				c = (char)('a' + newPosition);
			}
			else if(c >= 'A' && c <= 'Z') {
				int newPosition = (13 + (c - 'A'))%26;
				c = (char)('A' + newPosition);
			}
			text = text + c;
		}
		assertEquals(text, document.toString());
	}
	
}
