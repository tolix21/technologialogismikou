package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import commands.CommandsFactory;
import commands.DocumentToSpeech;
import commands.EditDocument;
import commands.ReplayManager;
import commands.StartRecording;
import model.Document;
import model.FakeTTSFacade;

public class ReplayCommandTest {

	@Test
	public void testActionPerformed() {
		CommandsFactory commandsFactory = new CommandsFactory();
		EditDocument editDocument = (EditDocument) commandsFactory.createCommand("EditDocument");
		ReplayManager replayManager = new ReplayManager();
		editDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		
		FakeTTSFacade audioManager = new FakeTTSFacade();
		document.setAudioManager(audioManager);
		
		editDocument.setDocument(document);
		
		String text = "first line\nsecond line\nthird line\nfourth line";
		editDocument.giveInfo(text);
		editDocument.actionPerformed(null);
		
		StartRecording startRecording = new StartRecording();
		startRecording.setReplayManager(replayManager);
		
		startRecording.actionPerformed(null);
		
		
		DocumentToSpeech documentToSpeech = (DocumentToSpeech) commandsFactory.createCommand("Transform");
		documentToSpeech.setDocument(document);
		documentToSpeech.setReplayManager(replayManager);
		
		documentToSpeech.giveInfo(-1, -1);
		documentToSpeech.actionPerformed(null);
		
		documentToSpeech.giveInfo(1, 2);
		documentToSpeech.actionPerformed(null);
		
		documentToSpeech.giveInfo(-1, -1);
		documentToSpeech.actionPerformed(null);
		
		String expected = document.toString() + " second line third line " + document.toString();
		
		assertEquals(expected, audioManager.getPlayedContents().strip());
	
		
	}
}
