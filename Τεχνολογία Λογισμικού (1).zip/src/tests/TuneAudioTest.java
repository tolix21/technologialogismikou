package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import commands.CommandsFactory;
import commands.DocumentToSpeech;
import commands.EditDocument;
import commands.ReplayManager;
import commands.TuneAudio;
import model.Document;
import model.FakeTTSFacade;

public class TuneAudioTest {

	@Test
	public void testActionPerformed() {
		CommandsFactory commandsFactory = new CommandsFactory();
		ReplayManager replayManager = new ReplayManager();
	
		FakeTTSFacade audioManager = new FakeTTSFacade();
		
		TuneAudio tuneAudio = (TuneAudio) commandsFactory.createCommand("Tune");
		tuneAudio.giveInfo((float) 0.5, 200, 300);
		tuneAudio.setAudioManager(audioManager);
		
		tuneAudio.actionPerformed(null);
		
		assertEquals(0.5, audioManager.getVolume(), 0.0);
		assertEquals(200, audioManager.getPitch(), 0.0);
		assertEquals(300, audioManager.getRate(), 0.0);
		
	
	}

}
