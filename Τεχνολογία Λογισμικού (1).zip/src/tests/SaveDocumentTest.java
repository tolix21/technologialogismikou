package tests;

import static org.junit.Assert.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.junit.Test;

import commands.CommandsFactory;
import commands.OpenDocument;
import commands.ReplayManager;
import commands.SaveDocument;
import commands.StartRecording;
import input.DocumentReaderFactory;
import model.Document;
import output.DocumentWriterFactory;

public class SaveDocumentTest {

	@Test
	public void testActionPerformed() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.docx", "Word", "None");
		openDocument.actionPerformed(null);
		
		
		SaveDocument saveDocument = (SaveDocument) commandsFactory.createCommand("SaveDocument");
		saveDocument.setDocument(document);
		saveDocument.setReplayManager(replayManager);
		DocumentWriterFactory writerFactory = new DocumentWriterFactory();
		document.setDocWriterFactory(writerFactory);
		saveDocument.giveInfo("testSaved.docx", "Word", "None");
		
		saveDocument.actionPerformed(null);
		
		String text = "";
		
		try (XWPFDocument doc = new XWPFDocument(
                Files.newInputStream(Paths.get("testSaved.docx")))) {

            
            List<XWPFParagraph> list = doc.getParagraphs();
            for (XWPFParagraph paragraph : list) {
                text = text + paragraph.getText() + "\n";
            }

        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		text = text.strip();
		assertEquals(text, document.toString());
	}

	@Test
	public void testActionPerformedAtbash() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.docx", "Word", "Atbash");
		openDocument.actionPerformed(null);
		
		
		SaveDocument saveDocument = (SaveDocument) commandsFactory.createCommand("SaveDocument");
		saveDocument.setDocument(document);
		saveDocument.setReplayManager(replayManager);
		DocumentWriterFactory writerFactory = new DocumentWriterFactory();
		document.setDocWriterFactory(writerFactory);
		saveDocument.giveInfo("testSaved.docx", "Word", "Atbash");
		
		saveDocument.actionPerformed(null);
		
		
		String text = "";
		
		try (XWPFDocument doc = new XWPFDocument(
                Files.newInputStream(Paths.get("testSaved.docx")))) {

            
            List<XWPFParagraph> list = doc.getParagraphs();
            for (XWPFParagraph paragraph : list) {
                text = text + paragraph.getText() + "\n";
            }

        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String oldText = text.strip();
		text = "";
		for(int j = 0; j < oldText.length(); j++) {
			char c = oldText.charAt(j);
			if(c >= 'a' && c <= 'z') {
				int newPosition = 25 - (c - 'a');
				c = (char)('a' + newPosition);
			}
			else if(c >= 'A' && c <= 'Z') {
				int newPosition = 25 - (c - 'A');
				c = (char)('A' + newPosition);
			}
			text = text + c;
		}
		assertEquals(text, document.toString());
	}
	
	@Test
	public void testActionPerformedRot13() {
		CommandsFactory commandsFactory = new CommandsFactory();
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		
		ReplayManager replayManager = new ReplayManager();
		openDocument.setReplayManager(replayManager);
		
		Document document = new Document();
		openDocument.setDocument(document);
		
		DocumentReaderFactory factory = new DocumentReaderFactory();
		document.setDocReaderFactory(factory);
		
		openDocument.giveInfo("test.docx", "Word", "Rot13");
		openDocument.actionPerformed(null);
		
		SaveDocument saveDocument = (SaveDocument) commandsFactory.createCommand("SaveDocument");
		saveDocument.setDocument(document);
		saveDocument.setReplayManager(replayManager);
		DocumentWriterFactory writerFactory = new DocumentWriterFactory();
		document.setDocWriterFactory(writerFactory);
		saveDocument.giveInfo("testSaved.docx", "Word", "Rot13");
		
		saveDocument.actionPerformed(null);
		
		
		String text = "";
		
		try (XWPFDocument doc = new XWPFDocument(
                Files.newInputStream(Paths.get("testSaved.docx")))) {

            
            List<XWPFParagraph> list = doc.getParagraphs();
            for (XWPFParagraph paragraph : list) {
                text = text + paragraph.getText() + "\n";
            }

        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String oldText = text.strip();
		text = "";
		for(int j = 0; j < oldText.length(); j++) {
			char c = oldText.charAt(j);
			if(c >= 'a' && c <= 'z') {
				int newPosition = (13 + (c - 'a'))%26;
				c = (char)('a' + newPosition);
			}
			else if(c >= 'A' && c <= 'Z') {
				int newPosition = (13 + (c - 'A'))%26;
				c = (char)('A' + newPosition);
			}
			text = text + c;
		}
		assertEquals(text, document.toString());
	}
}
