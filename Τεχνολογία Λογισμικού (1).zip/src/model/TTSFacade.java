package model;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class TTSFacade {
	private VoiceManager vm;
	private Voice voice;
	
	
	public TTSFacade() {    
		System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");

		VoiceManager voiceManager = VoiceManager.getInstance();
        voice = voiceManager.getVoice("kevin");
        voice.allocate();
	}
	
	public TTSFacade(TTSFacade audioManager) {
		// TODO Auto-generated constructor stub
		
		System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");

		VoiceManager voiceManager = VoiceManager.getInstance();
        voice = voiceManager.getVoice("kevin");
        voice.allocate();
        
        float volume = audioManager.voice.getVolume();
        voice.setVolume(volume);
        float pitch = audioManager.voice.getPitch();
        voice.setPitch(pitch);
        float rate = audioManager.voice.getRate();
        voice.setRate(rate);
        
	}

	public void play(String contents) {
		voice.speak(contents);
	}
	
	public void setVolume(float volume) {
		voice.setVolume(volume);
	}
	
	public void setPitch(float pitch) {
		voice.setPitch(pitch);
	}
	public void setRate(float rate) {
		voice.setRate(rate);
	}
}
