package model;

import java.util.ArrayList;
import java.util.List;

import input.DocumentReader;
import input.DocumentReaderFactory;
import output.DocumentWriter;
import output.DocumentWriterFactory;

public class Document {
	private List<String> contents;
	private TTSFacade audioManager;
	private DocumentReader documentReader;
	private DocumentReaderFactory docReaderFactory;
	private DocumentWriter documentWriter;
	private DocumentWriterFactory docWriterFactory;
	
	public Document() {
		
	}

	public Document(Document other) {
		// TODO Auto-generated constructor stub
		contents = new ArrayList<String>();
		for(int i = 0; i < other.contents.size(); i++) {
			String str = other.contents.get(i);
			this.contents.add(new String(str));
		}
		
		audioManager = new TTSFacade(other.audioManager);
	}

	public void setAudioManager(TTSFacade audioManager) {
		this.audioManager = audioManager;
	}

	public void setDocReaderFactory(DocumentReaderFactory docReaderFactory) {
		this.docReaderFactory = docReaderFactory;
	}

	public void setDocWriterFactory(DocumentWriterFactory docWriterFactory) {
		this.docWriterFactory = docWriterFactory;
	}
	
	public void open(String fileName, String type, String encoding) {
		documentReader = docReaderFactory.createReader(fileName, type, encoding);
		contents = documentReader.read();
	}
	
	public void playContents() {
		audioManager.play(toString());
	}
	
	public void playLine(int line) {
		audioManager.play(contents.get(line));
	}
	
	public void save(String fileName, String type, String encoding) {
		documentWriter = docWriterFactory.createWriter(fileName, type, encoding);
		documentWriter.write(contents);
	}
	public void setContents(List<String> contents) {
		this.contents = contents;
	}
	
	public String toString() {
		String contentsStr = "";
		
		for(int i = 0; i < contents.size(); i++) {
			String str = contents.get(i);
			contentsStr = contentsStr + str + "\n";
		}
		
		return contentsStr.strip();
	}

	public int size() {
		// TODO Auto-generated method stub
		return contents.size();
	}
}
