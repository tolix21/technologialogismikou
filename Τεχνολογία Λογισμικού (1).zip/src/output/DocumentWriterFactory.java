package output;

public class DocumentWriterFactory {
	private WordWriter wordWriter;
	private ExcelWriter excelWriter;
	private WriterAtbashDecorator writerAtbashDecorator;
	private WriterRot13Decorator writerRot13Decorator;
	
	public DocumentWriterFactory() {
		wordWriter = new WordWriter();
		excelWriter = new ExcelWriter();
	}
	public DocumentWriter createWriter(String fileName, String type, String encoding) {
		// TODO Auto-generated method stub
		DocumentWriter component = null;

		
		if(type.equals("Word")) {
			wordWriter.setFileName(fileName);
			component = wordWriter;
		}
		else if(type.equals("Excel")) {
			excelWriter.setFileName(fileName);
			component = excelWriter;
		}
		else {
			return null;
		}
		
		if(encoding.equals("None")) {
			return component;
		}
		else if(encoding.equals("Atbash")){
			writerAtbashDecorator = new WriterAtbashDecorator(component);
			return writerAtbashDecorator;
		}
		else if(encoding.equals("Rot13")) {
			writerRot13Decorator = new WriterRot13Decorator(component);
			return writerRot13Decorator;
		}
		
		return null;
	}

}
