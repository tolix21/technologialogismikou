package output;

import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
public class ExcelWriter implements DocumentWriter{
	private String fileName;
	
	public ExcelWriter() {
		
	}
	
	@Override
	public void write(List<String> contents) {
		// TODO Auto-generated method stub
		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("New sheet");
        

        int rowNum = 0;
        
        for (int i = 0; i < contents.size(); i++) {
        	String str = contents.get(i);
        	String[] tokens = str.split("\t");
            Row row = sheet.createRow(rowNum++);
            int colNum = 0;
            for (String field : tokens) {
                Cell cell = row.createCell(colNum++);
                cell.setCellValue(field);
            }
        }

        try {
            FileOutputStream outputStream = new FileOutputStream(fileName);
            workbook.write(outputStream);
            workbook.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	public void setFileName(String fileName) {
		// TODO Auto-generated method stub
		this.fileName = fileName;
	}

}
