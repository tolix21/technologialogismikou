package output;

import java.util.ArrayList;
import java.util.List;

public class WriterRot13Decorator extends WriterDecorator{

	public WriterRot13Decorator(DocumentWriter componentWriter) {
		super(componentWriter);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void write(List<String> contents) {
		// TODO Auto-generated method stub
		
		List<String> encodedContents = new ArrayList<String>();
		
		for(int i = 0; i < contents.size(); i++) {
			String contentsI = contents.get(i);
			String newContentsI = "";
			for(int j = 0; j < contentsI.length(); j++) {
				char c = contentsI.charAt(j);
				if(c >= 'a' && c <= 'z') {
					int newPosition = (13 + (c - 'a'))%26;
					c = (char)('a' + newPosition);
				}
				else if(c >= 'A' && c <= 'Z') {
					int newPosition = (13 + (c - 'A'))%26;
					c = (char)('A' + newPosition);
				}
				newContentsI = newContentsI + c;
			}
			encodedContents.add(newContentsI);
		}
		componentWriter.write(encodedContents);
		
	}


}
