package output;

import java.util.List;

public interface DocumentWriter {
	public void write(List<String> contents);
}
