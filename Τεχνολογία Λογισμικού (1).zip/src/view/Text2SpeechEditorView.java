package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JTextField;

import com.sun.speech.freetts.FreeTTS;

import commands.CommandsFactory;
import commands.EditDocument;
import commands.EndRecording;
import commands.OpenDocument;
import commands.ReplayCommand;
import commands.ReplayManager;
import commands.SaveDocument;
import commands.StartRecording;
import commands.DocumentToSpeech;
import commands.TuneAudio;
import input.DocumentReaderFactory;
import model.Document;
import model.TTSFacade;
import output.DocumentWriterFactory;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Text2SpeechEditorView {

	private JFrame frame;
	private JTextField from;
	private JTextField to;
	private JTextField volume;
	private JTextField speechRate;
	private JTextField pitch;
	private Document document;
	private ReplayManager replayManager;
	private CommandsFactory commandsFactory;
	private TTSFacade audioManager;
	private boolean isFileLoaded;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Text2SpeechEditorView window = new Text2SpeechEditorView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Text2SpeechEditorView() {
		document = new Document();
		DocumentWriterFactory docWriterFactory = new DocumentWriterFactory();
		DocumentReaderFactory docReaderFactory = new DocumentReaderFactory();
		document.setDocReaderFactory(docReaderFactory);
		document.setDocWriterFactory(docWriterFactory);
		
		audioManager = new TTSFacade();
		document.setAudioManager(audioManager);
		
		replayManager = new ReplayManager();
		commandsFactory = new CommandsFactory();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		OpenDocument openDocument = (OpenDocument) commandsFactory.createCommand("OpenDocument");
		openDocument.setDocument(document);
		openDocument.setReplayManager(replayManager);
		
		EditDocument editDocument = (EditDocument) commandsFactory.createCommand("EditDocument");
		editDocument.setDocument(document);
		editDocument.setReplayManager(replayManager);
		
		SaveDocument saveDocument = (SaveDocument) commandsFactory.createCommand("SaveDocument");
		saveDocument.setDocument(document);
		saveDocument.setReplayManager(replayManager);
		
		StartRecording startRecordingCommand = (StartRecording)commandsFactory.createCommand("StartRecording");
		startRecordingCommand.setReplayManager(replayManager);

		EndRecording endRecordingCommand = (EndRecording)commandsFactory.createCommand("EndRecording");
		endRecordingCommand.setReplayManager(replayManager);
		
		ReplayCommand replayCommand = (ReplayCommand)commandsFactory.createCommand("Replay");
		replayCommand.setReplayManager(replayManager);
		
		DocumentToSpeech trasformToAudio = (DocumentToSpeech) commandsFactory.createCommand("Transform");
		trasformToAudio.setDocument(document);
		trasformToAudio.setReplayManager(replayManager);
		
		TuneAudio tuneAudio = (TuneAudio) commandsFactory.createCommand("Tune");
		tuneAudio.setReplayManager(replayManager);
		tuneAudio.setAudioManager(audioManager);
		
		
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JEditorPane editorPane = new JEditorPane();
		editorPane.setBounds(22, 124, 402, 629);
		frame.getContentPane().add(editorPane);
		
		JCheckBox excelBox = new JCheckBox("Excel");
		
		JCheckBox wordBox = new JCheckBox("Word");
		wordBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(wordBox.isSelected() == true) {
					excelBox.setSelected(false);
				}
				else {
					excelBox.setSelected(true);
				}
			}
		});
		wordBox.setBounds(22, 27, 93, 21);
		frame.getContentPane().add(wordBox);
		
		JRadioButton rot13Radio = new JRadioButton("Rot 13");

		JRadioButton atbashRadio = new JRadioButton("Atbash");
		atbashRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(atbashRadio.isSelected() == true) {
					rot13Radio.setSelected(false);
				}
			}
		});
		atbashRadio.setBounds(206, 27, 103, 21);
		frame.getContentPane().add(atbashRadio);
		
		
		excelBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(excelBox.isSelected() == true) {
					wordBox.setSelected(false);
				}
				else {
					wordBox.setSelected(true);
				}
			}
		});
		excelBox.setBounds(22, 71, 93, 21);
		frame.getContentPane().add(excelBox);
		
		rot13Radio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rot13Radio.isSelected() == true) {
					atbashRadio.setSelected(false);
				}
			}
		});
		rot13Radio.setBounds(206, 71, 103, 21);
		frame.getContentPane().add(rot13Radio);
		
		JButton open = new JButton("Open");
		open.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser jfileChooser = new JFileChooser(".");
				if(jfileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					String fileName = jfileChooser.getSelectedFile().getAbsolutePath();
					String fileType = "";
					if(wordBox.isSelected()) {
						fileType = "Word";
					}
					else if(excelBox.isSelected()) {
						fileType = "Excel";
					}
					else {
						JOptionPane.showMessageDialog(null, "No file type selected", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					String encoding = "None";
					if(atbashRadio.isSelected()) {
						encoding = "Atbash";
					}
					else if(rot13Radio.isSelected()) {
						encoding = "Rot13";
					}
					openDocument.giveInfo(fileName, fileType, encoding);
					openDocument.actionPerformed(e);
					editorPane.setText(document.toString());
					isFileLoaded = true;
				}
			}
		});
		open.setBounds(462, 137, 85, 21);
		frame.getContentPane().add(open);
		
		JButton save = new JButton("Save");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(isFileLoaded == false) {
					JOptionPane.showMessageDialog(null, "No file loaded", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				JFileChooser jfileChooser = new JFileChooser(".");
				if(jfileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
					String fileName = jfileChooser.getSelectedFile().getAbsolutePath();
					String fileType = "";
					if(wordBox.isSelected()) {
						fileType = "Word";
					}
					else if(excelBox.isSelected()) {
						fileType = "Excel";
					}
					else {
						JOptionPane.showMessageDialog(null, "No file type selected", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					String encoding = "None";
					if(atbashRadio.isSelected()) {
						encoding = "Atbash";
					}
					else if(rot13Radio.isSelected()) {
						encoding = "Rot13";
					}
					saveDocument.giveInfo(fileName, fileType, encoding);
					saveDocument.actionPerformed(e);
					
				}
			}
		});
		save.setBounds(462, 251, 85, 21);
		frame.getContentPane().add(save);
		
		JButton edit = new JButton("Edit");
		edit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(isFileLoaded == false) {
					JOptionPane.showMessageDialog(null, "No file loaded", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				editDocument.giveInfo(editorPane.getText());
				editDocument.actionPerformed(e);
			}
		});
		edit.setBounds(462, 189, 85, 21);
		frame.getContentPane().add(edit);
		
		JButton transformAll = new JButton("Transform all");
		transformAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(isFileLoaded == false) {
					JOptionPane.showMessageDialog(null, "No file loaded", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				trasformToAudio.giveInfo(-1, -1);
				trasformToAudio.actionPerformed(e);
			}
		});
		transformAll.setBounds(462, 315, 85, 21);
		frame.getContentPane().add(transformAll);
		
		JButton transformSelected = new JButton("Transform selected");
		transformSelected.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(isFileLoaded == false) {
					JOptionPane.showMessageDialog(null, "No file loaded", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					int start = Integer.parseInt(from.getText());
					int end = Integer.parseInt(to.getText());
					if(start < 0 || end < 0 || start > end || start >= document.size() || end >= document.size()) {
						JOptionPane.showMessageDialog(null, "Error with numbers", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					trasformToAudio.giveInfo(start, end);
					trasformToAudio.actionPerformed(e);

				}catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Error with numbers", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
		});
		transformSelected.setBounds(462, 371, 85, 21);
		frame.getContentPane().add(transformSelected);
		
		from = new JTextField();
		from.setBounds(434, 412, 41, 19);
		frame.getContentPane().add(from);
		from.setColumns(10);
		
		to = new JTextField();
		to.setBounds(526, 412, 31, 19);
		frame.getContentPane().add(to);
		to.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("to");
		lblNewLabel.setBounds(481, 415, 45, 13);
		frame.getContentPane().add(lblNewLabel);
		
		JButton tune = new JButton("Tune");
		tune.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				float vol = -1, rate = -1, pitchF = -1;
				try {
					vol = Float.parseFloat(volume.getText());
					vol /= 100;
					
					if(vol < 0 || vol > 100) {
						JOptionPane.showMessageDialog(null, "Error with volume", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}

				}catch(NumberFormatException e1) {
					
				}
				
				try {
					
					rate = Float.parseFloat(speechRate.getText());
					
					
					if(rate < 30) {
						JOptionPane.showMessageDialog(null, "Error with rate", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}

				}catch(NumberFormatException e1) {
					
				}
				
				try {
					pitchF = Float.parseFloat(pitch.getText());
					

				}catch(NumberFormatException e1) {
					
				}
				
				if(vol == -1 && rate == -1 && pitchF == -1) {
					JOptionPane.showMessageDialog(null, "Give at least one parameter", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				tuneAudio.giveInfo(vol, pitchF, rate);
				tuneAudio.actionPerformed(e);
				
			}
		});
		tune.setBounds(462, 461, 85, 21);
		frame.getContentPane().add(tune);
		
		volume = new JTextField();
		volume.setBounds(480, 509, 96, 19);
		frame.getContentPane().add(volume);
		volume.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Volume");
		lblNewLabel_2.setBounds(434, 512, 45, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Speech rate");
		lblNewLabel_1.setBounds(434, 545, 45, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		speechRate = new JTextField();
		speechRate.setBounds(481, 538, 96, 19);
		frame.getContentPane().add(speechRate);
		speechRate.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Pitch");
		lblNewLabel_3.setBounds(434, 588, 45, 13);
		frame.getContentPane().add(lblNewLabel_3);
		
		pitch = new JTextField();
		pitch.setBounds(480, 585, 96, 19);
		frame.getContentPane().add(pitch);
		pitch.setColumns(10);
		
		JButton startRecording = new JButton("Start recording");
		startRecording.addActionListener(startRecordingCommand);
		startRecording.setBounds(462, 641, 85, 21);
		frame.getContentPane().add(startRecording);
		
		JButton replay = new JButton("Replay");
		replay.addActionListener(replayCommand);
		replay.setBounds(462, 697, 85, 21);
		frame.getContentPane().add(replay);
		
		JButton endRecording = new JButton("End recording");
		endRecording.addActionListener(endRecordingCommand);
		endRecording.setBounds(462, 732, 85, 21);
		frame.getContentPane().add(endRecording);
	}
}
